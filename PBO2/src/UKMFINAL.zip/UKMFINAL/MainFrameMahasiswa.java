/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UKMFINAL;


/**
 *
 * @author Lycorice
 */
public class MainFrameMahasiswa {
    public static void main(String[] args) {
        FrameMahasiswa mainframe = new FrameMahasiswa();
        mainframe.setVisible(true);
        mainframe.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    }
}
